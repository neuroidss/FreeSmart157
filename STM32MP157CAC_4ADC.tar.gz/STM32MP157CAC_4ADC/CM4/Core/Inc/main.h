/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32mp1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "openamp.h"
#include "virt_uart.h"
#include "lock_resource.h"

#include "openamp_log.h"

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
/* USER CODE BEGIN Private defines */

//#define ADC1_START_Pin GPIO_PIN_3
//#define ADC1_START_GPIO_Port GPIOZ
#define ADC1_START_Pin GPIO_PIN_4
#define ADC1_START_GPIO_Port GPIOA
//#define ADC1_RESET_Pin GPIO_PIN_0
//#define ADC1_RESET_GPIO_Port GPIOZ
#define ADC1_RESET_Pin GPIO_PIN_5
#define ADC1_RESET_GPIO_Port GPIOA
//#define ADC1_DRDY_Pin GPIO_PIN_2
//#define ADC1_DRDY_GPIO_Port GPIOF

#define ADC2_START_Pin GPIO_PIN_7
#define ADC2_START_GPIO_Port GPIOA
#define ADC2_RESET_Pin GPIO_PIN_4
#define ADC2_RESET_GPIO_Port GPIOB
//#define ADC2_DRDY_Pin GPIO_PIN_2
//#define ADC2_DRDY_GPIO_Port GPIOF

#define ADC3_START_Pin GPIO_PIN_4
#define ADC3_START_GPIO_Port GPIOE
//#define ADC3_START_Pin GPIO_PIN_11
//#define ADC3_START_GPIO_Port GPIOE
#define ADC3_RESET_Pin GPIO_PIN_12
#define ADC3_RESET_GPIO_Port GPIOE
//#define ADC3_DRDY_Pin GPIO_PIN_2
//#define ADC3_DRDY_GPIO_Port GPIOF

#define ADC4_START_Pin GPIO_PIN_14
#define ADC4_START_GPIO_Port GPIOE
#define ADC4_RESET_Pin GPIO_PIN_5
#define ADC4_RESET_GPIO_Port GPIOE
//#define ADC4_DRDY_Pin GPIO_PIN_2
//#define ADC4_DRDY_GPIO_Port GPIOF

#define ADC5_START_Pin GPIO_PIN_0
#define ADC5_START_GPIO_Port GPIOI
#define ADC5_RESET_Pin GPIO_PIN_3
#define ADC5_RESET_GPIO_Port GPIOD
////#define ADC5_RESET_Pin GPIO_PIN_10
////#define ADC5_RESET_GPIO_Port GPIOB
//#define ADC5_RESET_Pin GPIO_PIN_1
//#define ADC5_RESET_GPIO_Port GPIOI
//#define ADC5_DRDY_Pin GPIO_PIN_2
//#define ADC5_DRDY_GPIO_Port GPIOF

#define ADC6_START_Pin GPIO_PIN_2
#define ADC6_START_GPIO_Port GPIOI
#define ADC6_RESET_Pin GPIO_PIN_3
#define ADC6_RESET_GPIO_Port GPIOC
//#define ADC6_RESET_Pin GPIO_PIN_3
//#define ADC6_RESET_GPIO_Port GPIOI
//#define ADC6_DRDY_Pin GPIO_PIN_2
//#define ADC6_DRDY_GPIO_Port GPIOF

#define ADC7_START_Pin GPIO_PIN_6
#define ADC7_START_GPIO_Port GPIOF
#define ADC7_RESET_Pin GPIO_PIN_7
#define ADC7_RESET_GPIO_Port GPIOF
//#define ADC7_DRDY_Pin GPIO_PIN_2
//#define ADC7_DRDY_GPIO_Port GPIOF

#define ADC8_START_Pin GPIO_PIN_8
#define ADC8_START_GPIO_Port GPIOF
#define ADC8_RESET_Pin GPIO_PIN_11
#define ADC8_RESET_GPIO_Port GPIOF
//#define ADC8_RESET_Pin GPIO_PIN_9
//#define ADC8_RESET_GPIO_Port GPIOF
//#define ADC8_DRDY_Pin GPIO_PIN_2
//#define ADC8_DRDY_GPIO_Port GPIOF

#define AD_START_Pin GPIO_PIN_7
#define AD_START_GPIO_Port GPIOH
#define AD_RESET_Pin GPIO_PIN_14
#define AD_RESET_GPIO_Port GPIOA
//#define AD_START_Pin GPIO_PIN_0
//#define AD_START_GPIO_Port GPIOF
//#define AD_RESET_Pin GPIO_PIN_1
//#define AD_RESET_GPIO_Port GPIOF
//#define AD_DRDY_Pin GPIO_PIN_2
//#define AD_DRDY_GPIO_Port GPIOF
//#
//#define AD_DRDY_Pin ADC1_DRDY_Pin
//#define AD_DRDY_GPIO_Port ADC1_DRDY_GPIO_Port

#define SPI1_NSS_Pin GPIO_PIN_4
#define SPI1_NSS_GPIO_Port GPIOA
#define SPI2_NSS_Pin GPIO_PIN_0
#define SPI2_NSS_GPIO_Port GPIOI
//#define SPI3_NSS_Pin GPIO_PIN_10
//#define SPI3_NSS_GPIO_Port GPIOA
#define SPI4_NSS_Pin GPIO_PIN_11
#define SPI4_NSS_GPIO_Port GPIOE
#define SPI5_NSS_Pin GPIO_PIN_6
#define SPI5_NSS_GPIO_Port GPIOF

#define SPI_DMA (1)
//#define SPI_DMA (0)

//#define SPI_NSS_SOFTWARE (1)
#define SPI_NSS_SOFTWARE (0)

#define SAI_DMA (1)
//#define SAI_DMA (0)

//#define uint8_ad_number ((1 + 3) * 1)
//#define uint8_ad_adc_number (1)
//#define uint8_ad_adc_number (2)
//#define uint8_ad_adc_number (3)
#define uint8_ad_adc_number (4)
//#define uint8_ad_chan_number (1)
//#define uint8_ad_chan_number (2)
#define uint8_ad_chan_number (8)
//#define uint8_accel_chan_number (1)
//#define uint8_ad_number ((1 + 3) * 8)
#define uint8_ad_number ((1 + 3) * uint8_ad_chan_number)
//#define uint8_accel_chan_number (1)
//#define uint8_accel_chan_number (0)
#define uint8_accel_chan_number (3)

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

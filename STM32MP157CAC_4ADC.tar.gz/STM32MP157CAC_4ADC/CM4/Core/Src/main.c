/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "openamp.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "ad7779.h"
#include "platform_drivers.h"
#include "openamp_log.h"
#include "openamp_conf.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

enum {
  TRANSFER_WAIT,
  TRANSFER_COMPLETE,
  TRANSFER_ERROR
};

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define MAX_BUFFER_SIZE RPMSG_BUFFER_SIZE
#define BUFFERSIZE (2)

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
IPCC_HandleTypeDef hipcc;

SAI_HandleTypeDef hsai_BlockA3;
DMA_HandleTypeDef hdma_sai3_a;

SPI_HandleTypeDef hspi1;
SPI_HandleTypeDef hspi2;
SPI_HandleTypeDef hspi3;
SPI_HandleTypeDef hspi4;
SPI_HandleTypeDef hspi5;
DMA_HandleTypeDef hdma_spi2_rx;
DMA_HandleTypeDef hdma_spi2_tx;
DMA_HandleTypeDef hdma_spi5_tx;
DMA_HandleTypeDef hdma_spi5_rx;

UART_HandleTypeDef huart3;
DMA_HandleTypeDef hdma_usart3_rx;
DMA_HandleTypeDef hdma_usart3_tx;

/* USER CODE BEGIN PV */

///* Buffer used for transmission */
//uint8_t aTxBuffer[BUFFERSIZE];
//
///* Buffer used for reception */
//uint8_t aRxBuffer[BUFFERSIZE];

/* transfer state */
__IO uint32_t wTransferState = TRANSFER_WAIT;

VIRT_UART_HandleTypeDef huart0;
VIRT_UART_HandleTypeDef huart1;

__IO FlagStatus VirtUart0RxMsg = RESET;
uint8_t VirtUart0ChannelBuffRx[MAX_BUFFER_SIZE];
uint16_t VirtUart0ChannelRxSize = 0;

__IO FlagStatus VirtUart1RxMsg = RESET;
uint8_t VirtUart1ChannelBuffRx[MAX_BUFFER_SIZE];
uint16_t VirtUart1ChannelRxSize = 0;

typedef struct OVData {
//    uint32_t start;
    uint32_t start;
    uint32_t counter;
//    uint8_t counter;
  uint8_t datas[uint8_ad_adc_number][uint8_ad_number];
//  uint32_t end;
  uint32_t end;
} OVData;
OVData ovdata;

#define PRODUCTION_MODE (0)
//#define PRODUCTION_MODE (1)

//#define ADC_ON (0)
////#define ADC_ON (1)
//#define ADC_INIT (0)
////#define ADC_INIT (1)
//#define ADC_TEXT_INIT (0)
////#define ADC_TEXT_INIT (1)
//#define ADC_READ (0)
////#define ADC_READ (1)
//#define ADC_SHOW_TEXT (0)
////#define ADC_SHOW_TEXT (1)
//#define ADC_WRITE_OPENVIBE (0)
////#define ADC_WRITE_OPENVIBE (1)
//#define ADC_SHOW_REG (0)
////#define ADC_SHOW_REG (1)
////#define GPIO_TOGGLE_PINS (0)
//#define GPIO_TOGGLE_PINS (1)

//#define ADC_ON (0)
#define ADC_ON (1)
//#define ADC_INIT (0)
#define ADC_INIT (1)
#define ADC_TEXT_INIT (0)
//#define ADC_TEXT_INIT (1)
//#define ADC_READ (0)
#define ADC_READ (1)
#define ADC_SHOW_TEXT (0)
//#define ADC_SHOW_TEXT (1)
//#define ADC_WRITE_OPENVIBE (0)
#define ADC_WRITE_OPENVIBE (1)
#define ADC_SHOW_REG (0)
//#define ADC_SHOW_REG (1)
#define GPIO_TOGGLE_PINS (0)
//#define GPIO_TOGGLE_PINS (1)
//#define PRINT_DELAY (0)
#define PRINT_DELAY (1)


#define VIRT_UART (0)
//#define VIRT_UART (1)

#define uint8_data_number_print  300
uint8_t dataBuffer_print[uint8_data_number_print];

uint8_t datas[uint8_ad_adc_number][uint8_ad_number];
uint8_t aTxBuffer[uint8_ad_number];
uint8_t aRxBuffer[uint8_ad_number];

ad7779_dev *devices[uint8_ad_adc_number];

uint8_t ui8SampleNumber=-1;

uint8_t data1[uint8_ad_number];

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void PeriphCommonClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_IPCC_Init(void);
static void MX_SAI3_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_SPI4_Init(void);
static void MX_SPI2_Init(void);
static void MX_SPI5_Init(void);
static void MX_SPI3_Init(void);
int MX_OPENAMP_Init(int RPMsgRole, rpmsg_ns_bind_cb ns_bind_cb);
/* USER CODE BEGIN PFP */

void VIRT_UART0_RxCpltCallback(VIRT_UART_HandleTypeDef *huart);
void VIRT_UART1_RxCpltCallback(VIRT_UART_HandleTypeDef *huart);

void print_hex(int v, int num_places)
{
    const uint32_t uint32_data_number = (num_places % 4 == 0 ? num_places / 4 : num_places / 4 + 1);
    uint32_t uint32_data_number_written;
//  uint8_t dataBuffer[uint8_data_number];
  while (HAL_UART_GetState(&huart3) != HAL_UART_STATE_READY)
  {
  }
  int mask=0, n, num_nibbles, digit, nibbles_max;

    for (n=1; n<=num_places; n++)
    {
        mask = (mask << 1) | 0x0001;
    }
    v = v & mask; // truncate v to specified number of places

    num_nibbles = num_places / 4;
    if ((num_places % 4) != 0)
    {
        ++num_nibbles;
    }
    nibbles_max=num_nibbles;

    do
    {
        digit = ((v >> (num_nibbles-1) * 4)) & 0x0f;
        if(digit == 0)  dataBuffer_print[ nibbles_max-num_nibbles ] = '0';
        if(digit == 1)  dataBuffer_print[ nibbles_max-num_nibbles ] = '1';
        if(digit == 2)  dataBuffer_print[ nibbles_max-num_nibbles ] = '2';
        if(digit == 3)  dataBuffer_print[ nibbles_max-num_nibbles ] = '3';
        if(digit == 4)  dataBuffer_print[ nibbles_max-num_nibbles ] = '4';
        if(digit == 5)  dataBuffer_print[ nibbles_max-num_nibbles ] = '5';
        if(digit == 6)  dataBuffer_print[ nibbles_max-num_nibbles ] = '6';
        if(digit == 7)  dataBuffer_print[ nibbles_max-num_nibbles ] = '7';
        if(digit == 8)  dataBuffer_print[ nibbles_max-num_nibbles ] = '8';
        if(digit == 9)  dataBuffer_print[ nibbles_max-num_nibbles ] = '9';
        if(digit == 10) dataBuffer_print[ nibbles_max-num_nibbles ] = 'A';
        if(digit == 11) dataBuffer_print[ nibbles_max-num_nibbles ] = 'B';
        if(digit == 12) dataBuffer_print[ nibbles_max-num_nibbles ] = 'C';
        if(digit == 13) dataBuffer_print[ nibbles_max-num_nibbles ] = 'D';
        if(digit == 14) dataBuffer_print[ nibbles_max-num_nibbles ] = 'E';
        if(digit == 15) dataBuffer_print[ nibbles_max-num_nibbles ] = 'F';
    } while(--num_nibbles);
//    HAL_UART_Transmit_DMA(&huart1, dataBuffer, uint8_data_number);
//    HAL_UART_Transmit(&huart1, (uint8_t*)dataBuffer, uint8_data_number, 5000);

    if(VIRT_UART)
    {
      VIRT_UART_Transmit(&huart0, dataBuffer_print, uint32_data_number);
//      VIRT_UART_Transmit(&huart1, dataBuffer_print, uint32_data_number);
    }

//    if(UART_DMA)
//    {
        if(HAL_UART_Transmit_DMA(&huart3, (uint8_t*)dataBuffer_print, uint32_data_number) != HAL_OK)
        {
          Error_Handler();
        }
//    } else
//    {
//        if(HAL_UART_Transmit(&huart1, (uint8_t*)dataBuffer_print, uint32_data_number,5000) != HAL_OK)
//        {
//          Error_Handler();
//        }
//    }
//
//    if(FREESMARTEEG_SEND & FREESMARTEEG_SEND_SD)
//    {
//
//      if((retSD = f_write (&SDFile, dataBuffer_print, uint32_data_number, &uint32_data_number_written)) == FR_OK)
//        {
//
//        }
//      if((retSD = f_sync (&SDFile)) == FR_OK)
//      {
//
//      }
//
//    }


//    while (HAL_UART_GetState(&huart1) != HAL_UART_STATE_READY)
    {
    }
}
void print_binary(int v, int num_places  )
{
  const uint32_t uint32_data_number = num_places;
  uint32_t uint32_data_number_written;
//  uint8_t dataBuffer[uint8_data_number];
  while (HAL_UART_GetState(&huart3) != HAL_UART_STATE_READY)
  {
  }
    int mask=0, n;

    for (n=1; n<=num_places; n++)
    {
        mask = (mask << 1) | 0x0001;
    }
    v = v & mask;  // truncate v to specified number of places

    while(num_places)
    {

        if (v & (0x0001 << (num_places-1)))
        {
//             Serial.print("1");
             dataBuffer_print[ uint32_data_number-num_places ] = '1';
        }
        else
        {
//             Serial.print("0");
          dataBuffer_print[ uint32_data_number-num_places ] = '0';
         }

        --num_places;
        if(((num_places%4) == 0) && (num_places != 0))
        {
//            Serial.print("_");
        }
    }

    if(VIRT_UART)
    {
      VIRT_UART_Transmit(&huart0, dataBuffer_print, uint32_data_number);
//      VIRT_UART_Transmit(&huart1, dataBuffer_print, uint32_data_number);
    }

//    HAL_UART_Transmit_DMA(&huart1, dataBuffer, uint8_data_number);
//    HAL_UART_Transmit(&huart1, (uint8_t*)dataBuffer, uint8_data_number, 5000);
//    if(UART_DMA)
    {
        if(HAL_UART_Transmit_DMA(&huart3, (uint8_t*)dataBuffer_print, uint32_data_number) != HAL_OK)
        {
          Error_Handler();
        }
//    } else
//    {
//        if(HAL_UART_Transmit(&huart3, (uint8_t*)dataBuffer_print, uint32_data_number,5000) != HAL_OK)
//        {
//          Error_Handler();
//        }
    }

//    if(FREESMARTEEG_SEND & FREESMARTEEG_SEND_SD)
//    {
//
//      if((retSD = f_write (&SDFile, dataBuffer_print, uint32_data_number, &uint32_data_number_written)) == FR_OK)
//        {
//
//        }
//      if((retSD = f_sync (&SDFile)) == FR_OK)
//      {
//
//      }
//
//    }

    //    while (HAL_UART_GetState(&huart1) != HAL_UART_STATE_READY)
    {
    }
}
void print_symbol(uint8_t v)
{
  const uint32_t uint32_data_number = 1;
  uint32_t uint32_data_number_written;
//  uint8_t dataBuffer[uint8_data_number];
  while (HAL_UART_GetState(&huart3) != HAL_UART_STATE_READY)
  {
  }
  dataBuffer_print[ 0 ] = v;
//  HAL_UART_Transmit_DMA(&huart1, (uint8_t*)dataBuffer, uint8_data_number);
//  HAL_UART_Transmit(&huart1, (uint8_t*)dataBuffer, uint8_data_number, 5000);
//  HAL_UART_Transmit_IT(&huart1, (uint8_t*)dataBuffer, uint8_data_number);

  if(VIRT_UART)
  {
    VIRT_UART_Transmit(&huart0, dataBuffer_print, uint32_data_number);
//    VIRT_UART_Transmit(&huart1, dataBuffer_print, uint32_data_number);
  }

//  if(UART_DMA)
//  {
      if(HAL_UART_Transmit_DMA(&huart3, (uint8_t*)dataBuffer_print, uint32_data_number) != HAL_OK)
      {
        Error_Handler();
      }
//  } else
//  {
//      if(HAL_UART_Transmit(&huart1, (uint8_t*)dataBuffer_print, uint32_data_number,5000) != HAL_OK)
//      {
//        Error_Handler();
//      }
//  }
//
//  if(FREESMARTEEG_SEND & FREESMARTEEG_SEND_SD)
//  {
//
//    if((retSD = f_write (&SDFile, dataBuffer_print, uint32_data_number, &uint32_data_number_written)) == FR_OK)
//      {
//
//      }
//    if((retSD = f_sync (&SDFile)) == FR_OK)
//    {
//
//    }
//
//  }

//  while (HAL_UART_GetState(&huart1) != HAL_UART_STATE_READY)
  {
  }
}
void print_line()
{
  const uint32_t uint32_data_number = 2;
  uint32_t uint32_data_number_written;
  while (HAL_UART_GetState(&huart3) != HAL_UART_STATE_READY)
  {
  }
  dataBuffer_print[ 0 ] = '\r';
  dataBuffer_print[ 1 ] = '\n';
  //    HAL_UART_Transmit_DMA(&huart1, dataBuffer, uint8_data_number);
//      HAL_UART_Transmit(&huart1, (uint8_t*)dataBuffer, uint8_data_number, 5000);

  if(VIRT_UART)
  {
    VIRT_UART_Transmit(&huart0, dataBuffer_print, uint32_data_number);
//    VIRT_UART_Transmit(&huart1, dataBuffer_print, uint32_data_number);
  }

//  if(UART_DMA)
//  {
      if(HAL_UART_Transmit_DMA(&huart3, (uint8_t*)dataBuffer_print, uint32_data_number) != HAL_OK)
      {
        Error_Handler();
      }
//  } else
//  {
//      if(HAL_UART_Transmit(&huart3, (uint8_t*)dataBuffer_print, uint32_data_number,5000) != HAL_OK)
//      {
//        Error_Handler();
//      }
//  }
//
//  if(FREESMARTEEG_SEND & FREESMARTEEG_SEND_SD)
//  {
//
//    if((retSD = f_write (&SDFile, dataBuffer_print, uint32_data_number, &uint32_data_number_written)) == FR_OK)
//      {
//
//      }
//    if((retSD = f_sync (&SDFile)) == FR_OK)
//    {
//
//    }
//
//  }

//  while (HAL_UART_GetState(&huart1) != HAL_UART_STATE_READY)
  {
  }
}
void print_text(const char * t)
{
  int text_length = strlen(t);
  const uint32_t uint32_data_number = text_length;
  uint32_t uint32_data_number_written;
//  uint8_t dataBuffer[uint8_data_number];
  for (int n=0; n<text_length; n++)
  {
//    dataBuffer[n] = (uint8_t)(t[n]);
    dataBuffer_print[n] = (uint8_t)(t[n]);
  }
//  HAL_UART_Transmit_DMA(&huart1, dataBuffer, uint8_data_number);
//  HAL_UART_Transmit(&huart1, (uint8_t*)dataBuffer, uint8_data_number, 5000);
//  HAL_UART_Transmit_IT(&huart1, (uint8_t*)dataBuffer, uint8_data_number);
  while (HAL_UART_GetState(&huart3) != HAL_UART_STATE_READY)
  {
  }

  if(VIRT_UART)
  {
    VIRT_UART_Transmit(&huart0, dataBuffer_print, uint32_data_number);
//    VIRT_UART_Transmit(&huart1, dataBuffer_print, uint32_data_number);
  }

//  if(UART_DMA)
//  {
//      if(HAL_UART_Transmit_DMA(&huart1, (uint8_t*)dataBuffer, uint8_data_number) != HAL_OK)
      if(HAL_UART_Transmit_DMA(&huart3, (uint8_t*)dataBuffer_print, uint32_data_number) != HAL_OK)
      {
        Error_Handler();
      }
//  } else
//  {
////      if(HAL_UART_Transmit(&huart1, (uint8_t*)dataBuffer, uint8_data_number,5000) != HAL_OK)
//      if(HAL_UART_Transmit(&huart1, (uint8_t*)dataBuffer_print, uint32_data_number,5000) != HAL_OK)
//      {
//        Error_Handler();
//      }
//  }
//
//  if(FREESMARTEEG_SEND & FREESMARTEEG_SEND_SD)
//  {
//
//    if((retSD = f_write (&SDFile, dataBuffer_print, uint32_data_number, &uint32_data_number_written)) == FR_OK)
//      {
//
//      }
//    if((retSD = f_sync (&SDFile)) == FR_OK)
//    {
//
//    }
//
//  }
//
//  while (HAL_UART_GetState(&huart1) != HAL_UART_STATE_READY)
//  {
//  }
}
void print_text_line(const char * t)
{
  print_text(t);
  print_line();
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  if(IS_ENGINEERING_BOOT_MODE())
  {
    /* Configure the system clock */
    SystemClock_Config();
  }

  if(IS_ENGINEERING_BOOT_MODE())
  {
    /* Configure the peripherals common clocks */
    PeriphCommonClock_Config();
  }

  if(PRODUCTION_MODE)
  {
  /* IPCC initialisation */
   MX_IPCC_Init();
  /* OpenAmp initialisation ---------------------------------*/
  MX_OPENAMP_Init(RPMSG_REMOTE, NULL);
   }
  /* USER CODE BEGIN SysInit */
  if(PRODUCTION_MODE)
  {

  //  /*HW semaphore Clock enable*/
//    __HAL_RCC_HSEM_CLK_ENABLE();
//
//  __HAL_RCC_SPI1_CLK_ENABLE();

  log_info("Cortex-M4 boot successful with STM32Cube FW version: v%ld.%ld.%ld \r\n",
                                            ((HAL_GetHalVersion() >> 24) & 0x000000FF),
                                            ((HAL_GetHalVersion() >> 16) & 0x000000FF),
                                            ((HAL_GetHalVersion() >> 8) & 0x000000FF));
  }
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_SAI3_Init();
  MX_USART3_UART_Init();
//  MX_SPI4_Init();
//  MX_SPI2_Init();
  if(!GPIO_TOGGLE_PINS)
    {
//	    MX_SPI1_Init();
  MX_SPI5_Init();
    }
//  MX_SPI3_Init();
  /* USER CODE BEGIN 2 */


  if(1)
    {
      /*Configure GPIO pin Output Level */
      HAL_GPIO_WritePin(AD_START_GPIO_Port, AD_START_Pin, GPIO_PIN_RESET);

      /*Configure GPIO pin Output Level */
      HAL_GPIO_WritePin(AD_RESET_GPIO_Port, AD_RESET_Pin, GPIO_PIN_RESET);

    GPIO_InitTypeDef GPIO_InitStruct = {0};

    /*Configure GPIO pin : ADC3_START_Pin */
    GPIO_InitStruct.Pin = AD_START_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//    PERIPH_LOCK(AD_START_GPIO_Port);
    HAL_GPIO_Init(AD_START_GPIO_Port, &GPIO_InitStruct);
//    PERIPH_UNLOCK(AD_START_GPIO_Port);

  //  /*Configure GPIO pins : ADC1_DRDY_Pin ACC_INT1_Pin */
  //  GPIO_InitStruct.Pin = AD_DRDY_Pin|ACC_INT1_Pin;
  //  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  //  GPIO_InitStruct.Pull = GPIO_NOPULL;
  //  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /*Configure GPIO pins : ADC3_RESET_Pin ACC_SDO_SAO_Pin */
    GPIO_InitStruct.Pin = AD_RESET_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//    PERIPH_LOCK(AD_RESET_GPIO_Port);
    HAL_GPIO_Init(AD_RESET_GPIO_Port, &GPIO_InitStruct);
//    PERIPH_UNLOCK(AD_RESET_GPIO_Port);
    }

  if(GPIO_TOGGLE_PINS)
    {
      HAL_GPIO_WritePin(ADC1_START_GPIO_Port, ADC1_START_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC1_RESET_GPIO_Port, ADC1_RESET_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC2_START_GPIO_Port, ADC2_START_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC2_RESET_GPIO_Port, ADC2_RESET_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC3_START_GPIO_Port, ADC3_START_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC3_RESET_GPIO_Port, ADC3_RESET_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC4_START_GPIO_Port, ADC4_START_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC4_RESET_GPIO_Port, ADC4_RESET_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC5_START_GPIO_Port, ADC5_START_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC5_RESET_GPIO_Port, ADC5_RESET_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC6_START_GPIO_Port, ADC6_START_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC6_RESET_GPIO_Port, ADC6_RESET_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC7_START_GPIO_Port, ADC7_START_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC7_RESET_GPIO_Port, ADC7_RESET_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC8_START_GPIO_Port, ADC8_START_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(ADC8_RESET_GPIO_Port, ADC8_RESET_Pin, GPIO_PIN_RESET);

    GPIO_InitTypeDef GPIO_InitStruct = {0};

    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//	  PERIPH_LOCK(ADC1_START_GPIO_Port);
//	  PERIPH_LOCK(ADC2_RESET_GPIO_Port);
//	  PERIPH_LOCK(ADC2_START_GPIO_Port);
//	  PERIPH_LOCK(ADC3_RESET_GPIO_Port);
//	  PERIPH_LOCK(ADC3_START_GPIO_Port);
//	  PERIPH_LOCK(ADC4_RESET_GPIO_Port);
//	  PERIPH_LOCK(ADC4_START_GPIO_Port);
//	  PERIPH_LOCK(ADC5_RESET_GPIO_Port);
//	  PERIPH_LOCK(ADC5_START_GPIO_Port);
//	  PERIPH_LOCK(ADC6_RESET_GPIO_Port);
//	  PERIPH_LOCK(ADC6_START_GPIO_Port);
//	  PERIPH_LOCK(ADC7_RESET_GPIO_Port);
//	  PERIPH_LOCK(ADC7_START_GPIO_Port);
//	  PERIPH_LOCK(ADC8_RESET_GPIO_Port);
//	  PERIPH_LOCK(ADC8_START_GPIO_Port);
    GPIO_InitStruct.Pin = ADC1_START_Pin;
    HAL_GPIO_Init(ADC1_START_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC1_RESET_Pin;
    HAL_GPIO_Init(ADC1_RESET_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC2_START_Pin;
    HAL_GPIO_Init(ADC2_START_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC2_RESET_Pin;
    HAL_GPIO_Init(ADC2_RESET_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC3_START_Pin;
    HAL_GPIO_Init(ADC3_START_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC3_RESET_Pin;
    HAL_GPIO_Init(ADC3_RESET_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC4_START_Pin;
    HAL_GPIO_Init(ADC4_START_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC4_RESET_Pin;
    HAL_GPIO_Init(ADC4_RESET_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC5_START_Pin;
    HAL_GPIO_Init(ADC5_START_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC5_RESET_Pin;
    HAL_GPIO_Init(ADC5_RESET_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC6_START_Pin;
    HAL_GPIO_Init(ADC6_START_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC6_RESET_Pin;
    HAL_GPIO_Init(ADC6_RESET_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC7_START_Pin;
    HAL_GPIO_Init(ADC7_START_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC7_RESET_Pin;
    HAL_GPIO_Init(ADC7_RESET_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC8_START_Pin;
    HAL_GPIO_Init(ADC8_START_GPIO_Port, &GPIO_InitStruct);
    GPIO_InitStruct.Pin = ADC8_RESET_Pin;
    HAL_GPIO_Init(ADC8_RESET_GPIO_Port, &GPIO_InitStruct);
//	  PERIPH_UNLOCK(ADC1_START_GPIO_Port);
//	  PERIPH_UNLOCK(ADC2_RESET_GPIO_Port);
//	  PERIPH_UNLOCK(ADC2_START_GPIO_Port);
//	  PERIPH_UNLOCK(ADC3_RESET_GPIO_Port);
//	  PERIPH_UNLOCK(ADC3_START_GPIO_Port);
//	  PERIPH_UNLOCK(ADC4_RESET_GPIO_Port);
//	  PERIPH_UNLOCK(ADC4_START_GPIO_Port);
//	  PERIPH_UNLOCK(ADC5_RESET_GPIO_Port);
//	  PERIPH_UNLOCK(ADC5_START_GPIO_Port);
//	  PERIPH_UNLOCK(ADC6_RESET_GPIO_Port);
//	  PERIPH_UNLOCK(ADC6_START_GPIO_Port);
//	  PERIPH_UNLOCK(ADC7_RESET_GPIO_Port);
//	  PERIPH_UNLOCK(ADC7_START_GPIO_Port);
//	  PERIPH_UNLOCK(ADC8_RESET_GPIO_Port);
//	  PERIPH_UNLOCK(ADC8_START_GPIO_Port);

    }

  /*
   * Create Virtual UART device
   * defined by a rpmsg channel attached to the remote device
   */
  if(PRODUCTION_MODE)
  {
  log_info("Virtual UART0 OpenAMP-rpmsg channel creation\r\n");
  if (VIRT_UART_Init(&huart0) != VIRT_UART_OK) {
    log_err("VIRT_UART_Init UART0 failed.\r\n");
    Error_Handler();
  }

  log_info("Virtual UART1 OpenAMP-rpmsg channel creation\r\n");
  if (VIRT_UART_Init(&huart1) != VIRT_UART_OK) {
    log_err("VIRT_UART_Init UART1 failed.\r\n");
    Error_Handler();
  }

  /*Need to register callback for message reception by channels*/
  if(VIRT_UART_RegisterCallback(&huart0, VIRT_UART_RXCPLT_CB_ID, VIRT_UART0_RxCpltCallback) != VIRT_UART_OK)
  {
   Error_Handler();
  }
  if(VIRT_UART_RegisterCallback(&huart1, VIRT_UART_RXCPLT_CB_ID, VIRT_UART1_RxCpltCallback) != VIRT_UART_OK)
  {
    Error_Handler();
  }
  }
  if(ADC_ON)
  {
  	  HAL_GPIO_WritePin(AD_START_GPIO_Port, AD_START_Pin, GPIO_PIN_RESET);

	  //RESET
	  HAL_GPIO_WritePin(AD_RESET_GPIO_Port, AD_RESET_Pin, GPIO_PIN_RESET);
	  if(PRINT_DELAY)
	  for (int count_delay = 0; count_delay < 10; count_delay++) { print_hex(count_delay, 8); }
//	  HAL_Delay(100);
	  HAL_GPIO_WritePin(AD_RESET_GPIO_Port, AD_RESET_Pin, GPIO_PIN_SET);
	  if(PRINT_DELAY)
	  for (int count_delay = 0; count_delay < 10; count_delay++) { print_hex(count_delay, 8); }
//	  HAL_Delay(100);
  }

  if(ADC_INIT)
  {
    ad7779_dev *device1;
    ad7779_init_param init_param;
    uint8_t i;

//    init_param.spi_dev = &hspi1;
//      init_param.spi_dev.dev = &hspi1;
//      init_param.spi_dev.dev = &hspi2;
//    init_param.spi_dev.chip_select_port = AD_CS_GPIO_Port;
//    init_param.spi_dev.chip_select_pin = AD_CS_Pin;
    init_param.ctrl_mode = AD7779_SPI_CTRL;

    init_param.spi_crc_en = AD7779_DISABLE;
//    init_param.spi_crc_en = AD7779_ENABLE;

//      if(FREESMARTEEG_OUT & FREESMARTEEG_TEXT)
//      {
//        init_param.spi_crc_en = AD7779_DISABLE;
//      }

    for (i = AD7779_CH0; i <= AD7779_CH7; i++)
    {
//        init_param.state[i] = AD7779_DISABLE;
      init_param.state[i] = AD7779_ENABLE;
    }
//      init_param.state[0] = AD7779_DISABLE;
//    init_param.state[1] = AD7779_DISABLE;
//    init_param.state[2] = AD7779_DISABLE;
//    init_param.state[0] = AD7779_ENABLE;
//      init_param.state[1] = AD7779_ENABLE;
//      init_param.state[2] = AD7779_ENABLE;
//      init_param.state[3] = AD7779_ENABLE;
//      init_param.state[4] = AD7779_ENABLE;
//      init_param.state[1] = AD7779_ENABLE;

    for (i = AD7779_CH0; i <= AD7779_CH7; i++) {
//        init_param.gain[i] = AD7779_GAIN_1;
//      init_param.gain[i] = AD7779_GAIN_2;
//        init_param.gain[i] = AD7779_GAIN_4;
      init_param.gain[i] = AD7779_GAIN_8;
    }

    init_param.pwr_mode = AD7779_HIGH_RES;
//  //    init_param.dec_rate_int = 0xfff;//hr 0.5001221 kHz
    init_param.dec_rate_int = 0xfa0;//hr 0.512 kHz
//      init_param.dec_rate_int = 0xc80;//hr 0.640 kHz
//    init_param.dec_rate_int = 0xa00;//hr 0.800 kHz
//      init_param.dec_rate_int = 0x800;//hr 1 kHz
//      init_param.dec_rate_int = 0x400;//hr 2 kHz
//      init_param.dec_rate_int = 0x200;//hr 4 kHz
//      init_param.dec_rate_int = 0x100;//hr 8 kHz
//      init_param.dec_rate_int = 0x80;//hr 16 kHz
//          init_param.dec_rate_int = 0x40;//hr 32 kHz
//          init_param.dec_rate_int = 0x20;//hr 64 kHz
//          init_param.dec_rate_int = 0x10;//hr 128 kHz

//      init_param.pwr_mode = AD7779_LOW_PWR;
//      init_param.dec_rate_int = 0xfff;//lp 0.25006105 kHz
//    init_param.dec_rate_int = 0xfa0;//lp 0.256 kHz
//    init_param.dec_rate_int = 0xc80;//lp 0.320 kHz
//    init_param.dec_rate_int = 0xa00;//lp 0.400 kHz
//    init_param.dec_rate_int = 0x7d0;//lp 0.512 kHz
//    init_param.dec_rate_int = 0x800;//lp 0.500 kHz
//    init_param.dec_rate_int = 0x400;//lp 1 kHz
//    init_param.dec_rate_int = 0x200;//lp 2 kHz
//    init_param.dec_rate_int = 0x100;//lp 4 kHz
//    init_param.dec_rate_int = 0x80;//lp 8 kHz
//    init_param.dec_rate_int = 0x40;//lp 16 kHz

//    init_param.dec_rate_int = 0x20;//lp 64 kHz

    init_param.dec_rate_dec = 0;
//    init_param.dec_rate_dec = 0xfff;

    init_param.ref_type = AD7779_EXT_REF;
//      init_param.ref_type = AD7779_INT_REF;

//    init_param.pwr_mode = AD7779_HIGH_RES;
//    init_param.pwr_mode = AD7779_LOW_PWR;

    init_param.dclk_div = AD7779_DCLK_DIV_1;
//      init_param.dclk_div = AD7779_DCLK_DIV_2;
//      init_param.dclk_div = AD7779_DCLK_DIV_128;

    for (i = AD7779_CH0; i <= AD7779_CH7; i++) {
      init_param.sync_offset[i] = 0;
      init_param.offset_corr[i] = 0;
      init_param.gain_corr[i] = 0;
    }

//    init_param.spi_dev.dev = &hspi3;
//      init_param.spi_dev.dev = &hspi2;
    init_param.spi_dev.dev = &hspi5;
//    init_param.spi_dev.dev = &hspi4;
//    init_param.spi_dev.dev = &hspi1;
//      init_param.spi_dev.dev = &hspi1;
    init_param.spi_dev.chip_select_port = SPI5_NSS_GPIO_Port;
    init_param.spi_dev.chip_select_pin = SPI5_NSS_Pin;
//    init_param.spi_dev.chip_select_port = SPI4_NSS_GPIO_Port;
//    init_param.spi_dev.chip_select_pin = SPI4_NSS_Pin;
//      init_param.spi_dev.chip_select_port = SPI1_NSS_GPIO_Port;
//      init_param.spi_dev.chip_select_pin = SPI1_NSS_Pin;
//      init_param.spi_dev.chip_select_port = SPI2_NSS_GPIO_Port;
//      init_param.spi_dev.chip_select_pin = SPI2_NSS_Pin;
//      init_param.spi_dev.chip_select_port = SPI2_NSS_AD1_GPIO_Port;
//      init_param.spi_dev.chip_select_pin = SPI2_NSS_AD1_Pin;
//    init_param.spi_dev.dev = &hspi3;
//    init_param.spi_dev.chip_select_port = AD4_CS_GPIO_Port;
//    init_param.spi_dev.chip_select_pin = AD4_CS_Pin;
//    init_param.spi_dev.dev = &hspi3;
//    init_param.spi_dev.chip_select_port = AD3_CS_GPIO_Port;
//    init_param.spi_dev.chip_select_pin = AD3_CS_Pin;

//    init_param.dec_rate_int = 0x1000;//hr 0.5 kHz
//    init_param.dec_rate_int = 0x80;//hr 0.5 kHz
//    init_param.dec_rate_int = 0x40;//hr 0.5 kHz
//    init_param.dec_rate_int = 0x1000;//hr 0.5 kHz

//    HAL_GPIO_WritePin(init_param.spi_dev.chip_select_port, init_param.spi_dev.chip_select_pin, GPIO_PIN_SET);

//      if(FREESMARTEEG_ADC & FREESMARTEEG_ADC_DATA_READ)
//      {
//          HAL_Delay(1);
//          {
////            for(int ad_adc = 0; ad_adc < uint8_ad_adc_number; ad_adc ++)
//            {
//                aTxBuffer[0] = AD7779_REG_GENERAL_USER_CONFIG_1;
//                aTxBuffer[1] = AD7779_SOFT_RESET(3);
//                if(HAL_SPI_TransmitReceive_DMA(device1, aTxBuffer, datas[ad_adc], 2) != HAL_OK)
////                    if(HAL_SPI_TransmitReceive(devices[ad_adc]->spi_dev.dev, aTxBuffer, datas[ad_adc], 2, 5000) != HAL_OK)
//              {
//                Error_Handler();
//              }
//              while (HAL_SPI_GetState(device1) != HAL_SPI_STATE_READY)
//              {
//              }
//            }
//          }
//      }

//      ad7779_setup(&device1, init_param);
//
//      ad7779_spi_int_reg_write(device1,AD7779_REG_GENERAL_USER_CONFIG_1,AD7779_SOFT_RESET(3));
//      ad7779_spi_int_reg_write(device1,AD7779_REG_GENERAL_USER_CONFIG_1,AD7779_SOFT_RESET(2));

////      if(FREESMARTEEG_ADC & FREESMARTEEG_ADC_DATA_READ)
//      {
//          HAL_Delay(1);
//          {
//            for(int to_reset = 0; to_reset < 64; to_reset ++)
//            {
//                aTxBuffer[0] = 0x80;
//                aTxBuffer[1] = 0x00;
//                if(HAL_SPI_TransmitReceive_DMA(&hspi2, aTxBuffer, datas[ad_adc], 2) != HAL_OK)
////                    if(HAL_SPI_TransmitReceive(devices[ad_adc]->spi_dev.dev, aTxBuffer, datas[ad_adc], 2, 5000) != HAL_OK)
//              {
//                Error_Handler();
//              }
//              while (HAL_SPI_GetState(&hspi2) != HAL_SPI_STATE_READY)
//              {
//              }
//            }
//          }
//      }
////      if(FREESMARTEEG_ADC & FREESMARTEEG_ADC_DATA_READ)
//      {
//          HAL_Delay(1);
//          {
//            for(int ad_adc = 0; ad_adc < uint8_ad_adc_number; ad_adc ++)
//            {
//                aTxBuffer[0] = AD7779_REG_GENERAL_USER_CONFIG_1;
//                aTxBuffer[1] = AD7779_SOFT_RESET(2);
//                if(HAL_SPI_TransmitReceive_DMA(&hspi2, aTxBuffer, datas[ad_adc], 2) != HAL_OK)
////                    if(HAL_SPI_TransmitReceive(devices[ad_adc]->spi_dev.dev, aTxBuffer, datas[ad_adc], 2, 5000) != HAL_OK)
//              {
//                Error_Handler();
//              }
//              while (HAL_SPI_GetState(&hspi2) != HAL_SPI_STATE_READY)
//              {
//              }
//            }
//          }
//      }

    if(ADC_TEXT_INIT)
    {
    print_text_line(">>ad7779_setup(&device1, init_param);");
    }

    ad7779_setup(&device1, init_param);

    if(ADC_TEXT_INIT)
    {
    print_text_line("<<ad7779_setup(&device1, init_param);");
    }

    ad7779_spi_int_reg_write_mask(device1,AD7779_REG_SRC_UPDATE,AD7779_SRC_LOAD_SOURCE,AD7779_DISABLE);
    ad7779_spi_int_reg_write_mask(device1,AD7779_REG_SRC_UPDATE,AD7779_SRC_LOAD_UPDATE,AD7779_ENABLE);
	  if(PRINT_DELAY)
	  for (int count_delay = 0; count_delay < 10; count_delay++) { print_hex(count_delay, 8); }
//    HAL_Delay(1);
    ad7779_spi_int_reg_write_mask(device1,AD7779_REG_SRC_UPDATE,AD7779_SRC_LOAD_UPDATE,AD7779_DISABLE);

      devices[0]=device1;
//    devices[2]=device1;

//    ad7779_set_spi_op_mode(device, AD7779_SD_CONV);

//      if(uint8_ad_adc_number >= 2)
//      {
//      ad7779_dev *device2;
//      ad7779_init_param init_param2 = init_param;
//
//  //    init_param2.spi_dev.dev = &hspi4;
//      init_param2.spi_dev.dev = &hspi3;
////      init_param2.spi_dev.dev = &hspi3;
////      init_param2.spi_dev.dev = &hspi2;
//  //    init_param2.spi_dev.dev = &hspi1;
////      init_param2.spi_dev.chip_select_port = SPI3_NSS_GPIO_Port;
////      init_param2.spi_dev.chip_select_pin = SPI3_NSS_Pin;
////      init_param2.spi_dev.chip_select_port = SPI2_NSS_AD2_GPIO_Port;
////      init_param2.spi_dev.chip_select_pin = SPI2_NSS_AD2_Pin;
////  //    init_param2.spi_dev.dev = &hspi3;
//  //    init_param2.spi_dev.chip_select_port = AD4_CS_GPIO_Port;
//  //    init_param2.spi_dev.chip_select_pin = AD4_CS_Pin;
//  //    init_param2.spi_dev.dev = &hspi3;
//  //    init_param2.spi_dev.chip_select_port = AD3_CS_GPIO_Port;
//  //    init_param2.spi_dev.chip_select_pin = AD3_CS_Pin;
//
//  //    init_param2.dec_rate_int = 0x1000;//hr 0.5 kHz
//
//  //    HAL_GPIO_WritePin(init_param2.spi_dev.chip_select_port, init_param2.spi_dev.chip_select_pin, GPIO_PIN_SET);
//
//      ad7779_setup(&device2, init_param2);
//
//      ad7779_spi_int_reg_write_mask(device2,AD7779_REG_SRC_UPDATE,AD7779_SRC_LOAD_SOURCE,AD7779_DISABLE);
//      ad7779_spi_int_reg_write_mask(device2,AD7779_REG_SRC_UPDATE,AD7779_SRC_LOAD_UPDATE,AD7779_ENABLE);
//      HAL_Delay(1);
//      ad7779_spi_int_reg_write_mask(device2,AD7779_REG_SRC_UPDATE,AD7779_SRC_LOAD_UPDATE,AD7779_DISABLE);
//
//      devices[1]=device2;
//      }
//
//      if(uint8_ad_adc_number >= 3)
//      {
//      ad7779_dev *device3;
//      ad7779_init_param init_param3 = init_param;
//
////              init_param3.state[7] = AD7779_DISABLE;
//
//  //    init_param3.spi_dev.dev = &hspi1;
//      init_param3.spi_dev.dev = &hspi2;
////      init_param3.spi_dev.dev = &hspi3;
////      init_param3.spi_dev.dev = &hspi4;
//      init_param3.spi_dev.chip_select_port = SPI2_NSS_GPIO_Port;
//      init_param3.spi_dev.chip_select_pin = SPI2_NSS_Pin;
////      init_param3.spi_dev.chip_select_port = SPI2_NSS_AD3_GPIO_Port;
////      init_param3.spi_dev.chip_select_pin = SPI2_NSS_AD3_Pin;
//  //    init_param3.spi_dev.dev = &hspi3;
//  //    init_param3.spi_dev.chip_select_port = AD4_CS_GPIO_Port;
//  //    init_param3.spi_dev.chip_select_pin = AD4_CS_Pin;
//  //    init_param3.spi_dev.dev = &hspi1;
//  //    init_param3.spi_dev.chip_select_port = AD2_CS_GPIO_Port;
//  //    init_param3.spi_dev.chip_select_pin = AD2_CS_Pin;
//  //    init_param3.spi_dev.dev = &hspi1;
//  //    init_param3.spi_dev.chip_select_port = AD_CS_GPIO_Port;
//  //    init_param3.spi_dev.chip_select_pin = AD_CS_Pin;
//
//  //    init_param3.dec_rate_int = 0x100;//hr 16 kHz
//  //    init_param3.dec_rate_int = 0x1000;//hr 1 kHz
//  //    init_param3.dec_rate_int = 0x800;//hr 1 kHz
//
//  //    HAL_GPIO_WritePin(init_param3.spi_dev.chip_select_port, init_param3.spi_dev.chip_select_pin, GPIO_PIN_SET);
//
//      ad7779_setup(&device3, init_param3);
//
//      ad7779_spi_int_reg_write_mask(device3,AD7779_REG_SRC_UPDATE,AD7779_SRC_LOAD_SOURCE,AD7779_DISABLE);
//      ad7779_spi_int_reg_write_mask(device3,AD7779_REG_SRC_UPDATE,AD7779_SRC_LOAD_UPDATE,AD7779_ENABLE);
//      HAL_Delay(1);
//      ad7779_spi_int_reg_write_mask(device3,AD7779_REG_SRC_UPDATE,AD7779_SRC_LOAD_UPDATE,AD7779_DISABLE);
//
//      devices[2]=device3;
//      }
//
//      if(uint8_ad_adc_number >= 4)
//      {
//      ad7779_dev *device4;
//      ad7779_init_param init_param4 = init_param;
//
//  //    init_param4.spi_dev.dev = &hspi2;
//      init_param4.spi_dev.dev = &hspi4;
////      init_param4.spi_dev.dev = &hspi2;
//  //    init_param4.spi_dev.dev = &hspi3;
//      init_param4.spi_dev.chip_select_port = SPI4_NSS_GPIO_Port;
//      init_param4.spi_dev.chip_select_pin = SPI4_NSS_Pin;
////      init_param4.spi_dev.chip_select_port = SPI2_NSS_AD4_GPIO_Port;
////      init_param4.spi_dev.chip_select_pin = SPI2_NSS_AD4_Pin;
//  //    init_param4.spi_dev.dev = &hspi1;
//  //    init_param4.spi_dev.chip_select_port = AD2_CS_GPIO_Port;
//  //    init_param4.spi_dev.chip_select_pin = AD2_CS_Pin;
//  //    init_param4.spi_dev.dev = &hspi1;
//  //    init_param4.spi_dev.chip_select_port = AD_CS_GPIO_Port;
//  //    init_param4.spi_dev.chip_select_pin = AD_CS_Pin;
//
//  //    init_param4.dec_rate_int = 0x1000;//hr 1 kHz
//  //    init_param4.dec_rate_int = 0x800;//hr 1 kHz
//
//  //    HAL_GPIO_WritePin(init_param4.spi_dev.chip_select_port, init_param4.spi_dev.chip_select_pin, GPIO_PIN_SET);
//
//      ad7779_setup(&device4, init_param4);
//
//      ad7779_spi_int_reg_write_mask(device4,AD7779_REG_SRC_UPDATE,AD7779_SRC_LOAD_SOURCE,AD7779_DISABLE);
//      ad7779_spi_int_reg_write_mask(device4,AD7779_REG_SRC_UPDATE,AD7779_SRC_LOAD_UPDATE,AD7779_ENABLE);
//      HAL_Delay(1);
//      ad7779_spi_int_reg_write_mask(device4,AD7779_REG_SRC_UPDATE,AD7779_SRC_LOAD_UPDATE,AD7779_DISABLE);
//
//      devices[3]=device4;
//      }
  }
  if(ADC_INIT)
  {
//      if(FREESMARTEEG_ADC & FREESMARTEEG_ADC_SAI_READ_INT)
    {
//        HAL_Delay(100);
        {
            if(ADC_TEXT_INIT)
            {
          print_text_line(">>AD7779_REG_DOUT_FORMAT");
            }
//              print7_text_line(">>AD7779_REG_DOUT_FORMAT");
          int ad_adc = 0;
//            for(int ad_adc = 0; ad_adc < uint8_ad_adc_number; ad_adc ++)
          {
              aTxBuffer[0] = AD7779_REG_DOUT_FORMAT;
//                aTxBuffer[1] = AD7779_DOUT_FORMAT(0);//4 DOUTx lines
//                aTxBuffer[1] = AD7779_DOUT_FORMAT(1);//2 DOUTx lines
              aTxBuffer[1] = AD7779_DOUT_FORMAT(2);//1 DOUTx lines
//                aTxBuffer[1] = AD7779_DOUT_FORMAT(3);//1 DOUTx lines

                if(SPI_DMA)
                {
              wTransferState = TRANSFER_WAIT;
//              if(HAL_SPI_TransmitReceive(&hspi1, aTxBuffer, datas[ad_adc], 2, 1000) != HAL_OK)
//              if(HAL_SPI_TransmitReceive_IT(&hspi1, aTxBuffer, datas[ad_adc], 2) != HAL_OK)
//              if(HAL_SPI_TransmitReceive_DMA(&hspi1, aTxBuffer, datas[ad_adc], 2) != HAL_OK)
                  if(HAL_SPI_TransmitReceive_DMA(devices[ad_adc]->spi_dev.dev, aTxBuffer, datas[ad_adc], 2) != HAL_OK)
                  {
                    Error_Handler();
                  }
                } else {
                  if(SPI_NSS_SOFTWARE)
                  {
                    HAL_GPIO_WritePin(devices[ad_adc]->spi_dev.chip_select_port, devices[ad_adc]->spi_dev.chip_select_pin, GPIO_PIN_RESET);
                  }
                    if(HAL_SPI_TransmitReceive(devices[ad_adc]->spi_dev.dev, aTxBuffer, datas[ad_adc], 2, 5000) != HAL_OK)
                    {
                      Error_Handler();
                    }
                    if(SPI_NSS_SOFTWARE)
                    {
                    HAL_GPIO_WritePin(devices[ad_adc]->spi_dev.chip_select_port, devices[ad_adc]->spi_dev.chip_select_pin, GPIO_PIN_SET);
                    }
                }

//              while (wTransferState == TRANSFER_WAIT)
//              {
//                print_text_line("AD7779_REG_DOUT_FORMAT");
//              }

//              while (HAL_SPI_GetState(&hspi1) != HAL_SPI_STATE_READY)
              while (HAL_SPI_GetState(devices[ad_adc]->spi_dev.dev) != HAL_SPI_STATE_READY)
            {
            	    if(ADC_TEXT_INIT)
            	    {
                print_text_line("AD7779_REG_DOUT_FORMAT");
            	    }
            }
                if(ADC_TEXT_INIT)
                {
              print_text_line("<<AD7779_REG_DOUT_FORMAT");
                }
          }
//            print7_text_line("<<AD7779_REG_DOUT_FORMAT");
//            print7_text_line(">>AD7779_REG_GENERAL_USER_CONFIG_3");
//            int ad_adc = 2;
//            for(int ad_adc = uint8_ad_adc_number-1; ad_adc >= 0; ad_adc --)
//            for(int ad_adc = 0; ad_adc < uint8_ad_adc_number; ad_adc ++)
          {
        	    if(ADC_TEXT_INIT)
        	    {
            print_text_line(">>AD7779_REG_GENERAL_USER_CONFIG_2");
        	    }
//              int ad_adc = 0;
              aTxBuffer[0] = AD7779_REG_GENERAL_USER_CONFIG_2;
//                aTxBuffer[1] = AD7779_SDO_DRIVE_STR(1) | AD7779_DOUT_DRIVE_STR(0) | AD7779_SPI_SYNC;
//                aTxBuffer[1] = AD7779_SDO_DRIVE_STR(1) | AD7779_DOUT_DRIVE_STR(0);
//                aTxBuffer[1] = AD7771_FILTER_MODE | AD7779_SDO_DRIVE_STR(1) | AD7779_DOUT_DRIVE_STR(1) | AD7779_SPI_SYNC;
              aTxBuffer[1] = AD7771_FILTER_MODE | AD7779_SDO_DRIVE_STR(1) | AD7779_DOUT_DRIVE_STR(0) | AD7779_SPI_SYNC;

                if(SPI_DMA)
                {
              wTransferState = TRANSFER_WAIT;
//              if(HAL_SPI_TransmitReceive_DMA(&hspi1, aTxBuffer, datas[ad_adc], 2) != HAL_OK)
                  if(HAL_SPI_TransmitReceive_DMA(devices[ad_adc]->spi_dev.dev, aTxBuffer, datas[ad_adc], 2) != HAL_OK)
                  {
                    Error_Handler();
                  }
                } else {
                  if(SPI_NSS_SOFTWARE)
                  {
                    HAL_GPIO_WritePin(devices[ad_adc]->spi_dev.chip_select_port, devices[ad_adc]->spi_dev.chip_select_pin, GPIO_PIN_RESET);
                  }
                    if(HAL_SPI_TransmitReceive(devices[ad_adc]->spi_dev.dev, aTxBuffer, datas[ad_adc], 2, 5000) != HAL_OK)
                    {
                      Error_Handler();
                    }
                    if(SPI_NSS_SOFTWARE)
                    {
                    HAL_GPIO_WritePin(devices[ad_adc]->spi_dev.chip_select_port, devices[ad_adc]->spi_dev.chip_select_pin, GPIO_PIN_SET);
                    }
                }

//              while (wTransferState == TRANSFER_WAIT)
//              {
//              }

//              while (HAL_SPI_GetState(&hspi1) != HAL_SPI_STATE_READY)
            while (HAL_SPI_GetState(devices[ad_adc]->spi_dev.dev) != HAL_SPI_STATE_READY)
            {
                if(ADC_TEXT_INIT)
                {
              print_text_line("AD7779_REG_GENERAL_USER_CONFIG_2");
                }
            }
//              HAL_Delay(100);
                if(ADC_TEXT_INIT)
                {
              print_text_line("<<AD7779_REG_GENERAL_USER_CONFIG_2");
                }
          }
//            print7_text_line("<<AD7779_REG_GENERAL_USER_CONFIG_3");
        }
    }
    if(ADC_ON)
    {
        HAL_GPIO_WritePin(AD_START_GPIO_Port, AD_START_Pin, GPIO_PIN_RESET);
  	  if(PRINT_DELAY)
  	  for (int count_delay = 0; count_delay < 10; count_delay++) { print_hex(count_delay, 8); }
//        HAL_Delay(100);
        HAL_GPIO_WritePin(AD_START_GPIO_Port, AD_START_Pin, GPIO_PIN_SET);
  	  if(PRINT_DELAY)
  	  for (int count_delay = 0; count_delay < 10; count_delay++) { print_hex(count_delay, 8); }
//        HAL_Delay(100);
        HAL_GPIO_WritePin(AD_START_GPIO_Port, AD_START_Pin, GPIO_PIN_RESET);
    }

  }

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  int count=0;
  while (1)
  {

	    if(GPIO_TOGGLE_PINS)
	    {

	    	if(count%10000000==0)
	    	{
                print_hex(count/10000000%2, 8);//          print2_symbol(';');
                print_symbol(';');
                print_line();
	    	if(count/10000000%2)
	    	{

	    		  HAL_GPIO_WritePin(AD_RESET_GPIO_Port, AD_RESET_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(AD_START_GPIO_Port, AD_START_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC1_RESET_GPIO_Port, ADC1_RESET_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC1_START_GPIO_Port, ADC1_START_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC2_RESET_GPIO_Port, ADC2_RESET_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC2_START_GPIO_Port, ADC2_START_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC3_RESET_GPIO_Port, ADC3_RESET_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC3_START_GPIO_Port, ADC3_START_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC4_RESET_GPIO_Port, ADC4_RESET_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC4_START_GPIO_Port, ADC4_START_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC5_RESET_GPIO_Port, ADC5_RESET_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC5_START_GPIO_Port, ADC5_START_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC6_RESET_GPIO_Port, ADC6_RESET_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC6_START_GPIO_Port, ADC6_START_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC7_RESET_GPIO_Port, ADC7_RESET_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC7_START_GPIO_Port, ADC7_START_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC8_RESET_GPIO_Port, ADC8_RESET_Pin, GPIO_PIN_RESET);
	    		  HAL_GPIO_WritePin(ADC8_START_GPIO_Port, ADC8_START_Pin, GPIO_PIN_RESET);
	    	//      HAL_Delay(1000);
	    	} else {

	    	      HAL_GPIO_WritePin(AD_RESET_GPIO_Port, AD_RESET_Pin, GPIO_PIN_SET);
	    	      HAL_GPIO_WritePin(AD_START_GPIO_Port, AD_START_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC1_RESET_GPIO_Port, ADC1_RESET_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC1_START_GPIO_Port, ADC1_START_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC2_RESET_GPIO_Port, ADC2_RESET_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC2_START_GPIO_Port, ADC2_START_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC3_RESET_GPIO_Port, ADC3_RESET_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC3_START_GPIO_Port, ADC3_START_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC4_RESET_GPIO_Port, ADC4_RESET_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC4_START_GPIO_Port, ADC4_START_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC5_RESET_GPIO_Port, ADC5_RESET_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC5_START_GPIO_Port, ADC5_START_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC6_RESET_GPIO_Port, ADC6_RESET_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC6_START_GPIO_Port, ADC6_START_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC7_RESET_GPIO_Port, ADC7_RESET_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC7_START_GPIO_Port, ADC7_START_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC8_RESET_GPIO_Port, ADC8_RESET_Pin, GPIO_PIN_SET);
	    		  HAL_GPIO_WritePin(ADC8_START_GPIO_Port, ADC8_START_Pin, GPIO_PIN_SET);
	    	//      HAL_Delay(1000);
	    	}
	    	}
      count++;
	    }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
if(PRODUCTION_MODE)
{
    OPENAMP_check_for_message();

    if (VirtUart0RxMsg) {
      VirtUart0RxMsg = RESET;
      VIRT_UART_Transmit(&huart0, VirtUart0ChannelBuffRx, VirtUart0ChannelRxSize);
    }

    if (VirtUart1RxMsg) {
      VirtUart1RxMsg = RESET;
      VIRT_UART_Transmit(&huart1, VirtUart1ChannelBuffRx, VirtUart1ChannelRxSize);
    }
}

if(ADC_READ)
{
      HAL_SAI_Receive_DMA(&hsai_BlockA3, ovdata.datas[0], SAI_DATASIZE_32);
      while (HAL_SAI_GetState(&hsai_BlockA3) != HAL_SAI_STATE_READY)
      {
      }
}

      if(ADC_WRITE_OPENVIBE)
      {
          const uint32_t uint8_data_number = 2 + uint8_ad_chan_number * 3 * uint8_ad_adc_number + uint8_accel_chan_number * 2 + 1;
//              const uint32_t uint8_data_number = 2 + uint8_ad_chan_number * 3 * 4 + uint8_accel_chan_number * 2 + 1;
//              const uint32_t uint8_data_number = 2 + uint8_ad_chan_number * 3 * 1 + 0 * 2 + 1;
//              const uint32_t uint8_data_number = 2 + 1 * 3 * 1 + 0 * 2 + 1;
//              const uint32_t uint8_data_number = 2 + 1 * 3 * 1 + 1 * 2 + 1;
//              const uint32_t uint8_data_number = 2 + uint8_ad_chan_number * 3 * uint8_ad_adc_number + uint8_accel_chan_number * 2 + 1;
//              uint8_t dataBuffer[uint8_data_number];

        dataBuffer_print[0] = 0xA0;
        dataBuffer_print[1] = ui8SampleNumber++;

//            for(int ad_adc = 0; ad_adc < 1; ad_adc ++)
        for(int ad_adc = 0; ad_adc < uint8_ad_adc_number; ad_adc ++)
        {
//                for(int ad_data_channel = 0; ad_data_channel < 1; ad_data_channel ++)
          for(int ad_data_channel = 0; ad_data_channel < uint8_ad_chan_number; ad_data_channel ++)
          {
//                dataBuffer[2 + uint8_ad_chan_number * 3 * ad_adc + ad_data_channel * 3 + 0] = datas[ad_adc][ad_data_channel * 4 + 1];
//                dataBuffer[2 + uint8_ad_chan_number * 3 * ad_adc + ad_data_channel * 3 + 1] = datas[ad_adc][ad_data_channel * 4 + 2];
//                dataBuffer[2 + uint8_ad_chan_number * 3 * ad_adc + ad_data_channel * 3 + 2] = datas[ad_adc][ad_data_channel * 4 + 3];

            dataBuffer_print[2 + uint8_ad_chan_number * 3 * ad_adc + ad_data_channel * 3 + 0] = ovdata.datas[ad_adc][ad_data_channel * 4 + 2];
            dataBuffer_print[2 + uint8_ad_chan_number * 3 * ad_adc + ad_data_channel * 3 + 1] = ovdata.datas[ad_adc][ad_data_channel * 4 + 1];
            dataBuffer_print[2 + uint8_ad_chan_number * 3 * ad_adc + ad_data_channel * 3 + 2] = ovdata.datas[ad_adc][ad_data_channel * 4 + 0];
          }
        }
//            for(int accel_data_channel = 0; accel_data_channel < 0; accel_data_channel ++)
//            for(int accel_data_channel = 0; accel_data_channel < 1; accel_data_channel ++)
        for(int accel_data_channel = 0; accel_data_channel < uint8_accel_chan_number; accel_data_channel ++)
        {
          dataBuffer_print[2 + uint8_ad_chan_number * 3 * uint8_ad_adc_number + accel_data_channel * 2 + 0] = 0;
          dataBuffer_print[2 + uint8_ad_chan_number * 3 * uint8_ad_adc_number + accel_data_channel * 2 + 1] = 0;
        }
//            dataBuffer[2 + uint8_ad_chan_number * 3 * 1 + 0 * 2 + 0] = 0xC0;
//            dataBuffer[2 + 1 * 3 * 1 + 0 * 2 + 0] = 0xC0;
//            dataBuffer[2 + 1 * 3 * 1 + 1 * 2 + 0] = 0xC0;
//            dataBuffer[2 + uint8_ad_chan_number * 3 * 4 + uint8_accel_chan_number * 2 + 0] = 0xC0;
        dataBuffer_print[2 + uint8_ad_chan_number * 3 * uint8_ad_adc_number + uint8_accel_chan_number * 2 + 0] = 0xC0;

        if(VIRT_UART)
        {
        VIRT_UART_Transmit(&huart0, dataBuffer_print, uint8_data_number);
        }

//        if(FREESMARTEEG_SEND & FREESMARTEEG_SEND_UART1)
        {
          while (HAL_UART_GetState(&huart3) != HAL_UART_STATE_READY)
          {
          }
          if(HAL_UART_Transmit_DMA(&huart3, (uint8_t*)dataBuffer_print, uint8_data_number) != HAL_OK)
          {
            Error_Handler();
          }
        }

      }

      if(0)
      {
        for(int count = 0; ; count ++)
        {
          print_hex(count, 32);
          print_symbol(';');
        }
      }

      if(ADC_SHOW_TEXT)
//          if(SAI_RxCplt)
      {
//            SAI_RxCplt=0;

//              int crc_pair_ok[uint8_ad_adc_number][4];


//                  print7_hex(ad_adc1, 32);//          print2_symbol(';');
//                  print7_symbol(';');
//                for(int ad_adc = 0; ad_adc < 1; ad_adc ++)
//                  for(int ad_adc = 0; ad_adc < uint8_ad_adc_number; ad_adc ++)
                int ad_adc = 0;
//                int ad_adc = 3;
        {
          for(int ad_data_channel = 0; ad_data_channel < uint8_ad_chan_number; ad_data_channel ++)
          {
//                print7_binary(datas[ad_adc][ad_data_channel * 4 + 0], 8);//          print2_symbol(';');
//                print7_binary(datas[ad_adc][ad_data_channel * 4 + 1], 8);//          print2_symbol(';');
//                print7_binary(datas[ad_adc][ad_data_channel * 4 + 2], 8);//          print2_symbol(';');
//                print7_binary(datas[ad_adc][ad_data_channel * 4 + 3], 8);//          print2_symbol(';');

//                print7_binary(datas[ad_adc][ad_data_channel * 4 + 3], 8);//          print2_symbol(';');
//                print7_binary(datas[ad_adc][ad_data_channel * 4 + 2], 8);//          print2_symbol(';');
//                print7_binary(datas[ad_adc][ad_data_channel * 4 + 1], 8);//          print2_symbol(';');
//                print7_binary(datas[ad_adc][ad_data_channel * 4 + 0], 8);//          print2_symbol(';');

//                      print7_hex(datas[ad_adc][ad_data_channel * 4 + 0], 8);//          print2_symbol(';');
//                      print7_hex(datas[ad_adc][ad_data_channel * 4 + 1], 8);//          print2_symbol(';');
//                      print7_hex(datas[ad_adc][ad_data_channel * 4 + 2], 8);//          print2_symbol(';');
//                      print7_hex(datas[ad_adc][ad_data_channel * 4 + 3], 8);//          print2_symbol(';');

                    print_hex(ovdata.datas[ad_adc][ad_data_channel * 4 + 3], 8);//          print2_symbol(';');
                    print_hex(ovdata.datas[ad_adc][ad_data_channel * 4 + 2], 8);//          print2_symbol(';');
                    print_hex(ovdata.datas[ad_adc][ad_data_channel * 4 + 1], 8);//          print2_symbol(';');
                    print_hex(ovdata.datas[ad_adc][ad_data_channel * 4 + 0], 8);//          print2_symbol(';');

            print_symbol(';');
          }
          print_symbol(';');
        }
        print_symbol(';');

        print_line();

      }//FREESMARTEEG_SAI_TEXT_UART7_INT

      if(ADC_SHOW_REG)
      {
          int ad_adc = 0;
//        for(int ad_adc = 0; ad_adc < uint8_ad_adc_number; ad_adc ++)
          int reg = 1;
//        for(int reg = 0; reg < 17; reg ++)
        {
          switch(reg)
          {
          case 0:      data1[0] = 0x80 | AD7779_REG_CH_CONFIG(0); break;
          case 1:        data1[0] = 0x80 | AD7779_REG_GENERAL_USER_CONFIG_1; break;
          case 2:        data1[0] = 0x80 | AD7779_REG_GENERAL_USER_CONFIG_2; break;
          case 3:        data1[0] = 0x80 | AD7779_REG_GENERAL_USER_CONFIG_3; break;
          case 4:        data1[0] = 0x80 | AD7779_REG_DOUT_FORMAT; break;
          case 5:        data1[0] = 0x80 | AD7779_REG_BUFFER_CONFIG_1; break;
          case 6:        data1[0] = 0x80 | AD7779_REG_BUFFER_CONFIG_2; break;
          case 7:        data1[0] = 0x80 | AD7779_REG_CHX_ERR_REG_EN; break; break;
          case 8:        data1[0] = 0x80 | AD7779_REG_CH_ERR_REG(0); break;
          case 9:        data1[0] = 0x80 | AD7779_REG_CH0_1_SAT_ERR; break;
          case 10:        data1[0] = 0x80 | AD7779_REG_GEN_ERR_REG_1_EN; break;
          case 11:        data1[0] = 0x80 | AD7779_REG_GEN_ERR_REG_1; break;
          case 12:        data1[0] = 0x80 | AD7779_REG_GEN_ERR_REG_2_EN; break;
          case 13:  data1[0] = 0x80 | AD7779_REG_GEN_ERR_REG_2; break;
          case 14:        data1[0] = 0x80 | AD7779_REG_STATUS_REG_1; break;
          case 15:        data1[0] = 0x80 | AD7779_REG_STATUS_REG_2; break;
          case 16:        data1[0] = 0x80 | AD7779_REG_STATUS_REG_3; break;
          }
          data1[1] = 0;

          aTxBuffer[0] = data1[0];
          aTxBuffer[1] = data1[1];

          print_binary(data1[0], 8);    print_symbol(';');
          print_binary(data1[1], 8);    print_symbol(';');
          print_symbol(';');
//                print7_binary(data1[0], 8);    print7_symbol(';');
//                print7_binary(data1[1], 8);    print7_symbol(';');
//                print7_symbol(';');

    //      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
//         spi_write_and_read(0, data, 2);
    //      spi_write_and_read(0, data, 2);
//                if(HAL_SPI_TransmitReceive(devices[ad_adc]->spi_dev.dev, data1, data1, 2,5000) != HAL_OK)

          if(SPI_DMA)
          {
//              if(HAL_SPI_TransmitReceive_DMA(devices[ad_adc]->spi_dev.dev, data1, data1, 2) != HAL_OK)
//              {
//                Error_Handler();
//              }
              if(HAL_SPI_TransmitReceive_DMA(&hspi5, (uint8_t*)aTxBuffer, (uint8_t *)aRxBuffer, BUFFERSIZE) != HAL_OK)
//              if(HAL_SPI_TransmitReceive_DMA(&hspi2, (uint8_t*)aTxBuffer, (uint8_t *)aRxBuffer, BUFFERSIZE) != HAL_OK)
              {
                /* Transfer error in transmission process */
                Error_Handler();
              }

          } else {
            if(SPI_NSS_SOFTWARE)
            {
                HAL_GPIO_WritePin(SPI2_NSS_GPIO_Port, SPI2_NSS_Pin, GPIO_PIN_RESET);
//                HAL_GPIO_WritePin(devices[ad_adc]->spi_dev.chip_select_port, devices[ad_adc]->spi_dev.chip_select_pin, GPIO_PIN_RESET);
            }
            if(HAL_SPI_TransmitReceive(&hspi2, (uint8_t*)aTxBuffer, (uint8_t *)aRxBuffer, 2, 5000) != HAL_OK)
//              if(HAL_SPI_TransmitReceive(devices[ad_adc]->spi_dev.dev, data1, data1, 2, 5000) != HAL_OK)
              {
                Error_Handler();
              }
              if(SPI_NSS_SOFTWARE)
              {
                  HAL_GPIO_WritePin(SPI2_NSS_GPIO_Port, SPI2_NSS_Pin, GPIO_PIN_SET);
//                  HAL_GPIO_WritePin(devices[ad_adc]->spi_dev.chip_select_port, devices[ad_adc]->spi_dev.chip_select_pin, GPIO_PIN_SET);
              }
          }


//                print2_symbol('1');
//                if(HAL_SPI_TransmitReceive_DMA(&hspi1, aTxBuffer, data1, uint8_ad_number) != HAL_OK)
//                if(HAL_SPI_Receive_DMA(&hspi1, data1, uint8_ad_number) != HAL_OK)
//              if(HAL_SPI_TransmitReceive(device->spi_dev.dev, aTxBuffer, data, uint8_ad_number, 5000) != HAL_OK)
//          while (HAL_SPI_GetState(devices[ad_adc]->spi_dev.dev) != HAL_SPI_STATE_READY)
                while (HAL_SPI_GetState(&hspi2) != HAL_SPI_STATE_READY)
          {
                	print_symbol(';');
          }
//          HAL_SPI_TransmitReceive(&hspi1, data1, data1, 2, 5000);
      //    HAL_SPI_Transmit(&hspi1, data, 2, 5000);
    //      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);

          data1[0] = aRxBuffer[0];
          data1[1] = aRxBuffer[1];;

          print_binary(data1[0], 8);    print_symbol(';');
          print_binary(data1[1], 8);    print_symbol(';');
          print_symbol(';');
          print_symbol(';');
//                print7_binary(data1[0], 8);    print7_symbol(';');
//                print7_binary(data1[1], 8);    print7_symbol(';');
//                print7_symbol(';');
//                print7_symbol(';');

      //    print_line();
        }
        print_line();
//              print7_line();
      }


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_MEDIUMHIGH);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_CSI|RCC_OSCILLATORTYPE_HSI
                              |RCC_OSCILLATORTYPE_HSE|RCC_OSCILLATORTYPE_LSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS_DIG;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.HSIDivValue = RCC_HSI_DIV1;
  RCC_OscInitStruct.CSIState = RCC_CSI_ON;
  RCC_OscInitStruct.CSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLL12SOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 3;
  RCC_OscInitStruct.PLL.PLLN = 81;
  RCC_OscInitStruct.PLL.PLLP = 1;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLFRACV = 2048;
  RCC_OscInitStruct.PLL.PLLMODE = RCC_PLL_FRACTIONAL;
  RCC_OscInitStruct.PLL2.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL2.PLLSource = RCC_PLL12SOURCE_HSE;
  RCC_OscInitStruct.PLL2.PLLM = 3;
  RCC_OscInitStruct.PLL2.PLLN = 66;
  RCC_OscInitStruct.PLL2.PLLP = 2;
  RCC_OscInitStruct.PLL2.PLLQ = 1;
  RCC_OscInitStruct.PLL2.PLLR = 1;
  RCC_OscInitStruct.PLL2.PLLFRACV = 5120;
  RCC_OscInitStruct.PLL2.PLLMODE = RCC_PLL_FRACTIONAL;
  RCC_OscInitStruct.PLL3.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL3.PLLSource = RCC_PLL3SOURCE_HSE;
  RCC_OscInitStruct.PLL3.PLLM = 2;
  RCC_OscInitStruct.PLL3.PLLN = 34;
  RCC_OscInitStruct.PLL3.PLLP = 2;
  RCC_OscInitStruct.PLL3.PLLQ = 17;
  RCC_OscInitStruct.PLL3.PLLR = 37;
  RCC_OscInitStruct.PLL3.PLLRGE = RCC_PLL3IFRANGE_1;
  RCC_OscInitStruct.PLL3.PLLFRACV = 6660;
  RCC_OscInitStruct.PLL3.PLLMODE = RCC_PLL_FRACTIONAL;
  RCC_OscInitStruct.PLL4.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL4.PLLSource = RCC_PLL4SOURCE_HSE;
  RCC_OscInitStruct.PLL4.PLLM = 4;
  RCC_OscInitStruct.PLL4.PLLN = 99;
  RCC_OscInitStruct.PLL4.PLLP = 6;
  RCC_OscInitStruct.PLL4.PLLQ = 8;
  RCC_OscInitStruct.PLL4.PLLR = 8;
  RCC_OscInitStruct.PLL4.PLLRGE = RCC_PLL4IFRANGE_0;
  RCC_OscInitStruct.PLL4.PLLFRACV = 0;
  RCC_OscInitStruct.PLL4.PLLMODE = RCC_PLL_INTEGER;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** RCC Clock Config
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_ACLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_PCLK3|RCC_CLOCKTYPE_PCLK4
                              |RCC_CLOCKTYPE_PCLK5|RCC_CLOCKTYPE_MPU;
  RCC_ClkInitStruct.MPUInit.MPU_Clock = RCC_MPUSOURCE_PLL1;
  RCC_ClkInitStruct.MPUInit.MPU_Div = RCC_MPU_DIV2;
  RCC_ClkInitStruct.AXISSInit.AXI_Clock = RCC_AXISSOURCE_PLL2;
  RCC_ClkInitStruct.AXISSInit.AXI_Div = RCC_AXI_DIV1;
  RCC_ClkInitStruct.MCUInit.MCU_Clock = RCC_MCUSSOURCE_PLL3;
  RCC_ClkInitStruct.MCUInit.MCU_Div = RCC_MCU_DIV1;
  RCC_ClkInitStruct.APB4_Div = RCC_APB4_DIV2;
  RCC_ClkInitStruct.APB5_Div = RCC_APB5_DIV4;
  RCC_ClkInitStruct.APB1_Div = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2_Div = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB3_Div = RCC_APB3_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Set the HSE division factor for RTC clock
  */
  __HAL_RCC_RTC_HSEDIV(1);
}

/**
  * @brief Peripherals Common Clock Configuration
  * @retval None
  */
void PeriphCommonClock_Config(void)
{
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the common periph clock
  */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_CKPER;
  PeriphClkInit.CkperClockSelection = RCC_CKPERCLKSOURCE_HSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief IPCC Initialization Function
  * @param None
  * @retval None
  */
static void MX_IPCC_Init(void)
{

  /* USER CODE BEGIN IPCC_Init 0 */

  /* USER CODE END IPCC_Init 0 */

  /* USER CODE BEGIN IPCC_Init 1 */

  /* USER CODE END IPCC_Init 1 */
  hipcc.Instance = IPCC;
  if (HAL_IPCC_Init(&hipcc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN IPCC_Init 2 */

  /* USER CODE END IPCC_Init 2 */

}

/**
  * @brief SAI3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SAI3_Init(void)
{

  /* USER CODE BEGIN SAI3_Init 0 */

  /* USER CODE END SAI3_Init 0 */

  /* USER CODE BEGIN SAI3_Init 1 */

  /* USER CODE END SAI3_Init 1 */
  hsai_BlockA3.Instance = SAI3_Block_A;
  hsai_BlockA3.Init.AudioMode = SAI_MODESLAVE_RX;
  hsai_BlockA3.Init.Synchro = SAI_ASYNCHRONOUS;
  hsai_BlockA3.Init.OutputDrive = SAI_OUTPUTDRIVE_DISABLE;
  hsai_BlockA3.Init.FIFOThreshold = SAI_FIFOTHRESHOLD_EMPTY;
  hsai_BlockA3.Init.SynchroExt = SAI_SYNCEXT_DISABLE;
  hsai_BlockA3.Init.MonoStereoMode = SAI_STEREOMODE;
  hsai_BlockA3.Init.CompandingMode = SAI_NOCOMPANDING;
  hsai_BlockA3.Init.TriState = SAI_OUTPUT_NOTRELEASED;
  if (HAL_SAI_InitProtocol(&hsai_BlockA3, SAI_PCM_LONG, SAI_PROTOCOL_DATASIZE_32BIT, 8) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SAI3_Init 2 */

  /* USER CODE END SAI3_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_HARD_OUTPUT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 0x0;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_DISABLE;
  hspi1.Init.NSSPolarity = SPI_NSS_POLARITY_LOW;
  hspi1.Init.FifoThreshold = SPI_FIFO_THRESHOLD_01DATA;
  hspi1.Init.TxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi1.Init.RxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi1.Init.MasterSSIdleness = SPI_MASTER_SS_IDLENESS_00CYCLE;
  hspi1.Init.MasterInterDataIdleness = SPI_MASTER_INTERDATA_IDLENESS_00CYCLE;
  hspi1.Init.MasterReceiverAutoSusp = SPI_MASTER_RX_AUTOSUSP_DISABLE;
  hspi1.Init.MasterKeepIOState = SPI_MASTER_KEEP_IO_STATE_DISABLE;
  hspi1.Init.IOSwap = SPI_IO_SWAP_DISABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_HARD_OUTPUT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 0x0;
  hspi2.Init.NSSPMode = SPI_NSS_PULSE_DISABLE;
  hspi2.Init.NSSPolarity = SPI_NSS_POLARITY_LOW;
  hspi2.Init.FifoThreshold = SPI_FIFO_THRESHOLD_01DATA;
  hspi2.Init.TxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi2.Init.RxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi2.Init.MasterSSIdleness = SPI_MASTER_SS_IDLENESS_00CYCLE;
  hspi2.Init.MasterInterDataIdleness = SPI_MASTER_INTERDATA_IDLENESS_00CYCLE;
  hspi2.Init.MasterReceiverAutoSusp = SPI_MASTER_RX_AUTOSUSP_DISABLE;
  hspi2.Init.MasterKeepIOState = SPI_MASTER_KEEP_IO_STATE_DISABLE;
  hspi2.Init.IOSwap = SPI_IO_SWAP_DISABLE;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief SPI3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI3_Init(void)
{

  /* USER CODE BEGIN SPI3_Init 0 */

  /* USER CODE END SPI3_Init 0 */

  /* USER CODE BEGIN SPI3_Init 1 */

  /* USER CODE END SPI3_Init 1 */
  /* SPI3 parameter configuration*/
  hspi3.Instance = SPI3;
  hspi3.Init.Mode = SPI_MODE_MASTER;
  hspi3.Init.Direction = SPI_DIRECTION_2LINES;
  hspi3.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi3.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi3.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi3.Init.NSS = SPI_NSS_HARD_OUTPUT;
  hspi3.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi3.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi3.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi3.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi3.Init.CRCPolynomial = 0x0;
  hspi3.Init.NSSPMode = SPI_NSS_PULSE_DISABLE;
  hspi3.Init.NSSPolarity = SPI_NSS_POLARITY_LOW;
  hspi3.Init.FifoThreshold = SPI_FIFO_THRESHOLD_01DATA;
  hspi3.Init.TxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi3.Init.RxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi3.Init.MasterSSIdleness = SPI_MASTER_SS_IDLENESS_00CYCLE;
  hspi3.Init.MasterInterDataIdleness = SPI_MASTER_INTERDATA_IDLENESS_00CYCLE;
  hspi3.Init.MasterReceiverAutoSusp = SPI_MASTER_RX_AUTOSUSP_DISABLE;
  hspi3.Init.MasterKeepIOState = SPI_MASTER_KEEP_IO_STATE_DISABLE;
  hspi3.Init.IOSwap = SPI_IO_SWAP_DISABLE;
  if (HAL_SPI_Init(&hspi3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI3_Init 2 */

  /* USER CODE END SPI3_Init 2 */

}

/**
  * @brief SPI4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI4_Init(void)
{

  /* USER CODE BEGIN SPI4_Init 0 */

  /* USER CODE END SPI4_Init 0 */

  /* USER CODE BEGIN SPI4_Init 1 */

  /* USER CODE END SPI4_Init 1 */
  /* SPI4 parameter configuration*/
  hspi4.Instance = SPI4;
  hspi4.Init.Mode = SPI_MODE_MASTER;
  hspi4.Init.Direction = SPI_DIRECTION_2LINES;
  hspi4.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi4.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi4.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi4.Init.NSS = SPI_NSS_HARD_OUTPUT;
  hspi4.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi4.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi4.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi4.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi4.Init.CRCPolynomial = 0x0;
  hspi4.Init.NSSPMode = SPI_NSS_PULSE_DISABLE;
  hspi4.Init.NSSPolarity = SPI_NSS_POLARITY_LOW;
  hspi4.Init.FifoThreshold = SPI_FIFO_THRESHOLD_01DATA;
  hspi4.Init.TxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi4.Init.RxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi4.Init.MasterSSIdleness = SPI_MASTER_SS_IDLENESS_00CYCLE;
  hspi4.Init.MasterInterDataIdleness = SPI_MASTER_INTERDATA_IDLENESS_00CYCLE;
  hspi4.Init.MasterReceiverAutoSusp = SPI_MASTER_RX_AUTOSUSP_DISABLE;
  hspi4.Init.MasterKeepIOState = SPI_MASTER_KEEP_IO_STATE_DISABLE;
  hspi4.Init.IOSwap = SPI_IO_SWAP_DISABLE;
  if (HAL_SPI_Init(&hspi4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI4_Init 2 */

  /* USER CODE END SPI4_Init 2 */

}

/**
  * @brief SPI5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI5_Init(void)
{

  /* USER CODE BEGIN SPI5_Init 0 */

  /* USER CODE END SPI5_Init 0 */

  /* USER CODE BEGIN SPI5_Init 1 */

  /* USER CODE END SPI5_Init 1 */
  /* SPI5 parameter configuration*/
  hspi5.Instance = SPI5;
  hspi5.Init.Mode = SPI_MODE_MASTER;
  hspi5.Init.Direction = SPI_DIRECTION_2LINES;
  hspi5.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi5.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi5.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi5.Init.NSS = SPI_NSS_HARD_OUTPUT;
  hspi5.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi5.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi5.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi5.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi5.Init.CRCPolynomial = 0x0;
  hspi5.Init.NSSPMode = SPI_NSS_PULSE_DISABLE;
  hspi5.Init.NSSPolarity = SPI_NSS_POLARITY_LOW;
  hspi5.Init.FifoThreshold = SPI_FIFO_THRESHOLD_01DATA;
  hspi5.Init.TxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi5.Init.RxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi5.Init.MasterSSIdleness = SPI_MASTER_SS_IDLENESS_00CYCLE;
  hspi5.Init.MasterInterDataIdleness = SPI_MASTER_INTERDATA_IDLENESS_00CYCLE;
  hspi5.Init.MasterReceiverAutoSusp = SPI_MASTER_RX_AUTOSUSP_DISABLE;
  hspi5.Init.MasterKeepIOState = SPI_MASTER_KEEP_IO_STATE_DISABLE;
  hspi5.Init.IOSwap = SPI_IO_SWAP_ENABLE;
//  hspi5.Init.IOSwap = SPI_IO_SWAP_DISABLE;
  if (HAL_SPI_Init(&hspi5) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI5_Init 2 */

  /* USER CODE END SPI5_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 921600;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart3, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart3, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMAMUX_CLK_ENABLE();
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);
  /* DMA2_Stream1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream1_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream1_IRQn);
  /* DMA2_Stream2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream2_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream2_IRQn);
  /* DMA2_Stream3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream3_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream3_IRQn);
  /* DMA2_Stream4_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream4_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream4_IRQn);
  /* DMA2_Stream5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream5_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream5_IRQn);
  /* DMA2_Stream6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream6_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream6_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOI_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();

}

/* USER CODE BEGIN 4 */

void VIRT_UART0_RxCpltCallback(VIRT_UART_HandleTypeDef *huart)
{

    log_info("Msg received on VIRTUAL UART0 channel:  %s \n\r", (char *) huart->pRxBuffPtr);

    /* copy received msg in a variable to sent it back to master processor in main infinite loop*/
    VirtUart0ChannelRxSize = huart->RxXferSize < MAX_BUFFER_SIZE? huart->RxXferSize : MAX_BUFFER_SIZE-1;
    memcpy(VirtUart0ChannelBuffRx, huart->pRxBuffPtr, VirtUart0ChannelRxSize);
    VirtUart0RxMsg = SET;
}

void VIRT_UART1_RxCpltCallback(VIRT_UART_HandleTypeDef *huart)
{

    log_info("Msg received on VIRTUAL UART1 channel:  %s \n\r", (char *) huart->pRxBuffPtr);

    /* copy received msg in a variable to sent it back to master processor in main infinite loop*/
    VirtUart1ChannelRxSize = huart->RxXferSize < MAX_BUFFER_SIZE? huart->RxXferSize : MAX_BUFFER_SIZE-1;
    memcpy(VirtUart1ChannelBuffRx, huart->pRxBuffPtr, VirtUart1ChannelRxSize);
    VirtUart1RxMsg = SET;
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
//  HAL_SAI_Receive_DMA(&hsai_BlockA3, ovdata.datas[3], SAI_DATASIZE_32);

}

/**
  * @brief  TxRx Transfer completed callback.
  * @param  hspi: SPI handle
  * @note   This example shows a simple way to report end of DMA TxRx transfer, and
  *         you can add your own implementation.
  * @retval None
  */
void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{
  /* Turn LED7 on: Transfer in transmission/reception process is complete */
//  BSP_LED_On(LED7);
  wTransferState = TRANSFER_COMPLETE;
}

/**
  * @brief  SPI error callbacks.
  * @param  hspi: SPI handle
  * @note   This example shows a simple way to report transfer error, and you can
  *         add your own implementation.
  * @retval None
  */
void HAL_SPI_ErrorCallback(SPI_HandleTypeDef *hspi)
{
  wTransferState = TRANSFER_ERROR;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
